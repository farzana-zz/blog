<?php get_header(); ?>

	<div id="content">
		
		<?php query_posts($query_string . "&showposts=1"); ?>
		
		<?php if(have_posts()): ?><?php while(have_posts()) : the_post();?>
		
		<div class="post homepost" id="post-<?php the_ID(); ?>">
			<h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title();?></a></h2>
				
				<div class="entry">
					<p class="postmetadata">
	<?php the_time('d F Y') ?> | <?php the_category(', ') ?> | <?php  the_author(); ?> <?php edit_post_link('Edit', ' &#124; ', ''); ?><br />
					</p>
					<?php the_content('Continue');?>
					<p class="textright postmetadata"><?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?> </p>
				</div>
				
		</div>
		
		<?php endwhile; ?>
		
		<div class="navigation">
			<p class="floatleft"><?php next_posts_link('&laquo; Previous Entries') ?></p>
			<p class="floatright"><?php previous_posts_link('Next Entries &raquo;') ?></p>
		</div>		
		
		<?php else: ?>
		
		<div class="post">
			<h2><?php _e('Not Found'); ?></h2>
		</div>
		
		<?php endif; ?>
		
		<?php if (function_exists('mdv_recent_posts')): ?>
		
		<div id="recent">
			<h2>Recent Posts</h2>	
			<ul>
				<?php mdv_recent_posts(3, '<li>', '</li>', true, 1, true, false) ?>		
			</ul>
		</div>
		
		<?php endif; ?>
		
		<div id="bottomboxes" class="floatleft">
		
		<?php if (function_exists('mdv_recent_comments')) {?>
		
			<div id="recentcomments">
				<h2>Recent Comments</h2>
				<ul>
					<?php mdv_recent_comments(5, 5, '<li>', '</li>', true, 0) ?>
				</ul>
			</div>
			
		<?php } ?>
		
		<?php if (function_exists('akpc_most_popular')) {?>
		
			<div id="pop_posts">
				<h2>Popular Posts</h2>
				<ul>
					<?php akpc_most_popular($limit = 5, $before = '<li>', $after = '</li>'); ?>
				</ul>
			</div>
		
		<?php } ?>
		
		</div>
		
	</div>

	<?php get_sidebar(); ?>

	<?php get_footer(); ?>

</div>

</body>
</html>




















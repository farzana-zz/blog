<div id="sidebar">

	<div id="about">
		<img src="<?php bloginfo('stylesheet_directory'); ?>/img/about.jpg" height="90" width="310"alt="<?php bloginfo('description'); ?>" />
		<h2>about this blog</h2>
		<?php include(TEMPLATEPATH.'/about.php') ?>
	</div>
	
	<div class="left">
		<?php include(TEMPLATEPATH.'/leftwidgetbar.php') ?>
	</div>
	
	<div class="right">
		<?php include(TEMPLATEPATH.'/rightwidgetbar.php') ?>
	</div>
	
</div>
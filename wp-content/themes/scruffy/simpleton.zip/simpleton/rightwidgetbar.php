<ul>
	
	<?php if (function_exists('dynamic_sidebar')&&dynamic_sidebar('right')):else: ?>

		<li>
			<?php wp_list_bookmarks('categorize=0&title_li=Links&before=<li>&after=</li>&orderby=rand&category_before=&category_after='); ?>
		</li>
	
	<?php endif; ?>

</ul>
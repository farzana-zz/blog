<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array('name'=>'left'));
	register_sidebar(array('name'=>'right'));
?>
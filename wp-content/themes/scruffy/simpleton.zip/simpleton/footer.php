</div>

<div id="footer">

	<p>Copyright &copy; <?php bloginfo('name'); ?> 2007<br />
	Designed by <a href="http://fresh01.co.za" title="FRESH01 Freelance Web Design">Cobus Bester</a><br />
	Powered by <a href="http://www.wordpress.org">WordPress</a></p>

</div>


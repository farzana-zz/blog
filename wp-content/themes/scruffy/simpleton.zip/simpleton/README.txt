++SIMPLETON WORDPRESS THEME README++
Version: 1.0
Designer: Cobus Bester
Website: http://fresh01.co.za
Support: freesupport@fresh01.co.za

==NOTES==

Tested on WordPress vers. 2.3.2 in Microsoft Internet Explorer 7 and Mozilla FireFox vers. 2.0.0.11.
For any bugs or queries email: freesupport@fresh01.co.za

==Installation==

1. Copy the "simpleton" folder into wordpress/wp-content/themes.
2. Open your WordPress admin panel.
3. Click the "presentation" tab.
4. Select simpleton from the list of available themes.
5. Done and done.

==Required Plugins==

**The theme will still work without these plugins, but "recent posts", "recent comments" and "popular posts"
will be disabled.

1. Recent Comments - http://wordpress.org/extend/plugins/recent-comments/
2. Recent Posts - http://wordpress.org/extend/plugins/recent-posts/ (Requires optional excerpt for best performance)
3. Popularity Contest - http://alexking.org/projects/wordpress

==Customise==

1. To change the about information in the sidebar, edit the information in simpleton/about.php
2. To customise the about image. Create an image(dimensions: 310 x 90 px). Name the image about.jpg
   Place the image in the simpleton/img folder.